import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Usuario } from './usuario.entity';

@Injectable()
export class UsuarioService {
  constructor(
    @InjectRepository(Usuario)
    private readonly usuarioRepository: Repository<Usuario>,
  ) {}

  findAll(): Promise<Usuario[]> {
    return this.usuarioRepository.find();
  }

  async findOne(id_usuario: number): Promise<Usuario> {
    const usuario = await this.usuarioRepository.findOneBy({ id_usuario: id_usuario });
    if (!usuario) {
      throw new Error(`Usuario with id ${id_usuario} not found`);
    }
    return usuario;
  }

  create(usuario: Usuario): Promise<Usuario> {
    return this.usuarioRepository.save(usuario);
  }

  // Metodo para actualizar un usuario
  async update(id_usuario: number, usuario: Partial<Usuario>): Promise<Usuario | null> {
    await this.usuarioRepository.update({ id_usuario: id_usuario }, usuario);
    return this.findOne(id_usuario);
}

// Metodo para eliminar un usuario
async delete(id_usuario: number): Promise<void> {
    const user = await this.findOne(id_usuario);
    await this.usuarioRepository.delete(user);
}
}