import { Controller, Get, Post, Body, Param, Put, Delete, NotFoundException } from '@nestjs/common';
import { UsuarioService } from './usuario.service';
import { Usuario } from './usuario.entity';

@Controller('usuarios')
export class UsuarioController {
  constructor(private readonly usuarioService: UsuarioService) {}

  @Get()
  findAll(): Promise<Usuario[]> {
    return this.usuarioService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id_usuario: number): Promise<Usuario> {
    try {
      return await this.usuarioService.findOne(id_usuario);
    } catch (error) {
      throw new NotFoundException(error.message);
    }
  }

  @Post()
  create(@Body() usuario: Usuario): Promise<Usuario> {
    return this.usuarioService.create(usuario);
  }

  // Método para actualizar un usuario
  @Put(':id')
  update(@Param('id') id_usuario: number, @Body() usuario: Partial<Usuario>): Promise<Usuario | null> {
      return this.usuarioService.update(id_usuario, usuario);
  }

  // Método para eliminar un usuario
  @Delete(':id')
  delete(@Param('id') id_usuario: number): Promise<void> {
      return this.usuarioService.delete(id_usuario);
  }
}
