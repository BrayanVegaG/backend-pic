import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Producto } from './producto.entity';

@Injectable()
export class ProductoService {
  constructor(
    @InjectRepository(Producto)
    private readonly productoRepository: Repository<Producto>,
  ) {}

  findAll(): Promise<Producto[]> {
    return this.productoRepository.find();
  }

  async findOne(id: number): Promise<Producto> {
    const producto = await this.productoRepository.findOne({ where: { id_producto: id } });
    if (!producto) {
      throw new Error(`Producto with id ${id} not found`);
    }
    return producto;
  }

  async create(producto: Producto): Promise<Producto> {
    const now = new Date();

    const newProducto = this.productoRepository.create({
      ...producto,
      id_categoria: producto.id_categoria,
      id_empresa: producto.id_empresa,
      id_proveedor: producto.id_proveedor,
      fecha_creacion: now,
      ultima_actualizacion: now,
    });

    return this.productoRepository.save(newProducto);
  }

  async update(id_producto: number, producto: Producto): Promise<void> {
    const now = new Date();

    await this.productoRepository.update(id_producto, {
      ...producto,
      id_categoria: producto.id_categoria,
      id_empresa: producto.id_empresa,
      id_proveedor: producto.id_proveedor,
      ultima_actualizacion: now,
    });
  }

  async remove(id_producto: number): Promise<void> {
    await this.productoRepository.delete(id_producto);
  }
}